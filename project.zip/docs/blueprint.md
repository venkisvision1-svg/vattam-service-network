# **App Name**: VATTAM

## Core Features:

- Intelligent Tamil/English Search Tool: An AI-powered service matching tool that uses generative logic to understand intent and local dialect in both Tamil and English voice searches.
- Firebase-OTP & Multi-Role Identity: Secure mobile-first authentication for Customers, Technicians, Vendors, and Admins with automated role-based dashboard redirection.
- Socket-Sync Booking Flow: A production-ready booking system with real-time status updates, scheduling, and technician assignment managed through a centralized database.
- Digital QR Networking Hub: Instant generation of unique QR profile cards for business networking with WhatsApp integration and profile analytics.
- Integrated Financial Wallet: A comprehensive earning tracking system for service providers with secure withdrawal processing and transaction history.
- KYC Verification Pipeline: Document upload and verification interface for technician onboarding to ensure platform trust and safety.
- Premium Service Dashboard: A central marketplace interface categorizing specialized services like CCTV, plumbing, and solar with a high-end consumer-first UI.

## Style Guidelines:

- The primary color is a vibrant deep orange (#ff621a), evoking the energetic pulse of modern enterprise. The background is a sophisticated ink black (#0b0a09), which creates high-end contrast suitable for a premium agency aesthetic. The accent is a warm crimson (#db3d4a), chosen from an analogous palette to drive action and focus.
- We recommend a font pairing: 'Space Grotesk' for headlines to capture a computerized, tech-forward look, and 'Inter' (sans-serif) for body text to maintain objectivity and professional readability.
- A mobile-first grid using rounded glassmorphism cards and spacious padding to ensure an open, high-quality editorial feel reminiscent of leading modern apps.
- Minimalist, stroke-based iconography that remains thin and consistent to avoid clutter while guiding the user through complex booking flows.
- Smooth, physics-based transitions powered by Framer Motion, utilizing subtle vertical drifts and opacity fades to reinforce the premium branding.