'use server';
/**
 * @fileOverview An AI-powered service matching tool for VATTAM.
 *
 * Processes customer requests to identify service intent and booking readiness.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const IntelligentServiceSearchInputSchema = z.object({
  query: z.string().describe('The user\'s natural language service request.'),
  userLocation: z.string().optional().describe('Geographic location context.'),
  preferredLanguage: z.enum(['en', 'ta']).default('en'),
});

const IntelligentServiceSearchOutputSchema = z.object({
  detectedLanguage: z.enum(['en', 'ta']),
  serviceCategory: z.enum([
    'AC Service',
    'Refrigerator Repair',
    'Washing Machine Repair',
    'CCTV Installation',
    'Plumbing',
    'Electrician',
    'RO Service',
    'Painting',
    'Solar Installation',
    'Digital Marketing',
    'QR Code Business Setup',
    'Other',
  ]),
  keywords: z.array(z.string()),
  locationPreference: z.string().optional(),
  timePreference: z.string().optional(),
  bookingOptionsAvailable: z.boolean(),
  technicianAvailability: z.string(),
});

export async function intelligentServiceSearch(input: z.infer<typeof IntelligentServiceSearchInputSchema>) {
  return intelligentServiceSearchFlow(input);
}

const servicesList = [
  'AC Service', 'Refrigerator Repair', 'Washing Machine Repair', 
  'CCTV Installation', 'Plumbing', 'Electrician', 'RO Service', 
  'Painting', 'Solar Installation', 'Digital Marketing', 'QR Code Business Setup'
].join(', ');

const intelligentServiceSearchPrompt = ai.definePrompt({
  name: 'intelligentServiceSearchPrompt',
  input: { schema: IntelligentServiceSearchInputSchema },
  output: { schema: IntelligentServiceSearchOutputSchema },
  prompt: `You are an intelligent service matching assistant for VATTAM.
Available services: ${servicesList}

Analyze the user's query:
User Query: "{{{query}}}"
User Location: "{{#if userLocation}}{{{userLocation}}}{{else}}Not provided{{/if}}"
Preferred Language: "{{{preferredLanguage}}}"

Extract details and match to a category. If it's a household repair, identify urgency.`,
});

const intelligentServiceSearchFlow = ai.defineFlow(
  {
    name: 'intelligentServiceSearchFlow',
    inputSchema: IntelligentServiceSearchInputSchema,
    outputSchema: IntelligentServiceSearchOutputSchema,
  },
  async (input) => {
    const { output } = await intelligentServiceSearchPrompt(input);
    if (!output) throw new Error('AI output generation failed');
    return output;
  }
);
