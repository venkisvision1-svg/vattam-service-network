
"use client"

import React, { useState } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { 
  Clock, MapPin, CreditCard, ChevronRight, 
  CheckCircle2, AlertCircle, MessageSquare, Loader2
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { useUser, useFirestore } from "@/firebase"
import { createBooking } from "@/services/booking-service"
import { useRouter } from "next/navigation"

export default function BookingPage() {
  const { user } = useUser()
  const db = useFirestore()
  const router = useRouter()
  const [step, setStep] = useState<'details' | 'confirm'>('details')
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [timeSlot, setTimeSlot] = useState("10:00 AM")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const timeSlots = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "04:00 PM"]

  const handleBooking = async () => {
    if (!user) {
      router.push('/login')
      return
    }

    setIsSubmitting(true)
    try {
      const bookingData = {
        customerId: user.uid,
        serviceType: "AC Service", // This would be dynamic in a real app
        scheduledAt: new Date(date!.setHours(parseInt(timeSlot))),
        address: "Plot No 42, Anna Nagar, Chennai",
        price: 648,
        notes: "Standard cleaning request"
      }

      createBooking(db, bookingData)
      setStep('confirm')
    } catch (error) {
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <main className="min-h-screen pt-24 pb-20">
      <Navbar />
      <div className="container mx-auto px-4 md:px-8 max-w-4xl">
        <AnimatePresence mode="wait">
          {step === 'details' ? (
            <motion.div
              key="details"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="grid lg:grid-cols-3 gap-8"
            >
              <div className="lg:col-span-2 space-y-8">
                <Card className="glass border-white/10 rounded-[2rem]">
                  <CardHeader>
                    <CardTitle>Schedule Service</CardTitle>
                    <CardDescription>Select your preferred date and time</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="flex flex-col md:flex-row gap-8">
                      <div className="flex-1">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          className="rounded-2xl border-white/5 bg-white/5"
                        />
                      </div>
                      <div className="flex-1 space-y-4">
                        <h4 className="font-bold flex items-center">
                          <Clock className="w-4 h-4 mr-2 text-primary" /> Available Slots
                        </h4>
                        <div className="grid grid-cols-2 gap-3">
                          {timeSlots.map((slot) => (
                            <Button
                              key={slot}
                              variant={timeSlot === slot ? "default" : "outline"}
                              className={timeSlot === slot ? "bg-primary" : "border-white/10 hover:border-primary/50"}
                              onClick={() => setTimeSlot(slot)}
                            >
                              {slot}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass border-white/10 rounded-[2rem]">
                  <CardHeader>
                    <CardTitle>Service Address</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-start space-x-4 p-4 rounded-2xl bg-white/5 border border-white/5">
                      <MapPin className="w-6 h-6 text-primary mt-1" />
                      <div className="flex-1">
                        <p className="font-bold">Home</p>
                        <p className="text-sm text-muted-foreground">Plot No 42, Anna Nagar, Chennai, TN - 600040</p>
                      </div>
                      <Button variant="ghost" className="text-primary text-xs">Edit</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-8">
                <Card className="glass border-white/10 rounded-[2rem] sticky top-32">
                  <CardHeader>
                    <CardTitle>Payment Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Service Base Price</span>
                      <span>₹599</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Taxes & Fees</span>
                      <span>₹49</span>
                    </div>
                    <div className="pt-4 border-t border-white/5 flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span className="text-primary">₹648</span>
                    </div>
                    
                    <Button 
                      className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl text-lg font-bold mt-6"
                      onClick={handleBooking}
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : null}
                      {isSubmitting ? "Processing..." : "Confirm Booking"}
                    </Button>
                    
                    <p className="text-[10px] text-center text-muted-foreground mt-4">
                      Payments powered by Razorpay. Secure and trusted.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="confirm"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <Card className="glass border-white/10 p-12 space-y-8 rounded-[3rem]">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-12 h-12 text-primary" />
                </div>
                <div>
                  <h2 className="text-4xl font-bold mb-4">Booking Confirmed!</h2>
                  <p className="text-muted-foreground text-lg">We are assigning the best technician for you.</p>
                </div>
                
                <div className="bg-white/5 rounded-[2rem] p-8 text-left space-y-6 max-w-md mx-auto">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center">
                      <Clock className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Scheduled For</p>
                      <p className="font-bold">{date?.toLocaleDateString()} at {timeSlot}</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/dashboard" className="flex-1">
                    <Button className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl font-bold">
                      View Live Status
                    </Button>
                  </Link>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <Footer />
    </main>
  )
}
