
"use client"

import React, { useMemo } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  User, ShieldCheck, Briefcase, Wallet, Clock, 
  Settings, ChevronRight, BarChart3, QrCode, Plus, ArrowUpRight, IndianRupee, Loader2
} from "lucide-react"
import Link from "next/link"
import { useUser, useFirestore, useDoc, useCollection } from "@/firebase"
import { doc, collection, query, where, orderBy, limit } from "firebase/firestore"
import { Badge } from "@/components/ui/badge"

export default function Dashboard() {
  const { user, loading: userLoading } = useUser()
  const db = useFirestore()
  
  const userProfileRef = useMemo(() => {
    if (!user || !db) return null
    return doc(db, 'users', user.uid)
  }, [user, db])

  const walletRef = useMemo(() => {
    if (!user || !db) return null
    return doc(db, 'wallets', user.uid)
  }, [user, db])

  const bookingsQuery = useMemo(() => {
    if (!user || !db) return null
    return query(
      collection(db, 'bookings'),
      where('customerId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(5)
    )
  }, [user, db])

  const { data: profile, loading: profileLoading } = useDoc(userProfileRef)
  const { data: wallet } = useDoc(walletRef)
  const { data: recentBookings } = useCollection(bookingsQuery)

  const userRole = profile?.role || 'customer'

  if (userLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin h-12 w-12 text-primary" />
      </div>
    )
  }

  if (!user) {
    return (
      <main className="min-h-screen pt-24">
        <Navbar />
        <div className="container mx-auto px-4 text-center py-20">
          <h2 className="text-2xl font-bold mb-4">Please log in to access your dashboard</h2>
          <Link href="/login">
            <Button className="bg-primary rounded-xl px-8 h-12">Log In</Button>
          </Link>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen pt-24">
      <Navbar />
      <div className="container mx-auto px-4 md:px-8 pb-20">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 space-y-4 md:space-y-0">
          <div>
            <h1 className="font-headline font-bold text-3xl">Control Center</h1>
            <p className="text-muted-foreground capitalize">Welcome back, {profile?.displayName || 'User'}</p>
          </div>
          <div className="flex bg-secondary p-1 rounded-xl">
            <Badge variant="outline" className="border-primary text-primary px-4 py-1.5 rounded-lg uppercase">
              {userRole} Account
            </Badge>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <Card className="glass border-white/5 h-fit lg:col-span-1">
            <CardContent className="p-4 space-y-1">
              {[
                { name: "Overview", icon: BarChart3, active: true },
                { name: "Wallet & UPI", icon: Wallet, href: "/dashboard/wallet" },
                { name: "My Bookings", icon: Clock },
                { name: "QR Profile", icon: QrCode },
                { name: "KYC Verification", icon: ShieldCheck, show: userRole === 'technician' },
                { name: "Settings", icon: Settings },
              ].filter(item => item.show !== false).map((item, i) => (
                <Link key={i} href={item.href || "#"}>
                  <Button variant={item.active ? "secondary" : "ghost"} className="w-full justify-start rounded-xl mb-1">
                    <item.icon className="w-4 h-4 mr-3" />
                    {item.name}
                  </Button>
                </Link>
              ))}
            </CardContent>
          </Card>

          {/* Main Dashboard Area */}
          <div className="lg:col-span-3 space-y-8">
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="glass border-white/5 bg-gradient-to-br from-primary/10 to-transparent">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Bookings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{recentBookings?.length || 0}</div>
                  <p className="text-xs text-primary font-medium mt-1">Real-time status tracking</p>
                </CardContent>
              </Card>
              
              <Card className="glass border-white/5 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <IndianRupee className="w-12 h-12" />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Wallet Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">₹{wallet?.balance || 0}</div>
                  <div className="flex gap-2 mt-4">
                    <Link href="/dashboard/wallet" className="flex-1">
                      <Button size="sm" className="w-full bg-primary hover:bg-primary/90 text-xs rounded-lg">
                        <Plus className="w-3 h-3 mr-1" /> Add Funds
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass border-white/5">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Verification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-bold">{profile?.isActive ? 'Verified' : 'Pending'}</div>
                  <p className="text-xs text-muted-foreground mt-1">Status of your VATTAM ID</p>
                </CardContent>
              </Card>
            </div>

            <Card className="glass border-white/5">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Live status of your service requests</CardDescription>
                </div>
                <Button variant="outline" size="sm" className="border-white/10 rounded-lg">View All</Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentBookings && recentBookings.length > 0 ? (
                    recentBookings.map((item: any, i) => (
                      <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center">
                            <Briefcase className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="font-bold">{item.serviceType}</h4>
                            <p className="text-xs text-muted-foreground">₹{item.price} • {new Date(item.createdAt?.seconds * 1000).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-6">
                          <span className={`text-sm font-bold uppercase tracking-tighter ${
                            item.status === 'completed' ? 'text-emerald-400' : 
                            item.status === 'pending' ? 'text-primary' : 'text-blue-400'
                          }`}>
                            {item.status}
                          </span>
                          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-white transition-colors" />
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      No recent bookings found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {userRole === 'technician' && profile?.verificationStatus !== 'verified' && (
              <Card className="glass border-white/5 bg-accent/5 overflow-hidden">
                <div className="p-8 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">Complete Your KYC</h3>
                    <p className="text-muted-foreground max-w-md">To accept high-value premium bookings, please upload your Aadhaar and Skill Certificates.</p>
                  </div>
                  <Button className="bg-accent hover:bg-accent/90 rounded-xl h-12 px-8 font-bold">
                    Start Verification
                  </Button>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
