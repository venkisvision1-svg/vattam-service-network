
"use client"

import React, { useState, useMemo } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  Wallet, ArrowLeft, Smartphone, QrCode, CheckCircle2, AlertCircle, Loader2
} from "lucide-react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { useUser, useFirestore, useDoc } from "@/firebase"
import { doc } from "firebase/firestore"
import { processTransaction } from "@/services/wallet-service"

export default function WalletPage() {
  const { user } = useUser()
  const db = useFirestore()
  const [amount, setAmount] = useState("")
  const [step, setStep] = useState<'input' | 'payment' | 'success'>('input')
  const [paymentMethod, setPaymentMethod] = useState<'intent' | 'qr'>('intent')
  const [isProcessing, setIsSubmitting] = useState(false)

  const walletRef = useMemo(() => {
    if (!user || !db) return null
    return doc(db, 'wallets', user.uid)
  }, [user, db])

  const { data: wallet } = useDoc(walletRef)

  const handlePay = async () => {
    if (!amount || isNaN(Number(amount))) return
    setStep('payment')
  }

  const simulateSuccess = async () => {
    if (!user || !db) return
    setIsSubmitting(true)
    try {
      await processTransaction(
        db, 
        user.uid, 
        Number(amount), 
        'credit', 
        `Wallet top-up via UPI`
      )
      setStep('success')
    } catch (error) {
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const upiId = "vattam.pay@oksbi"
  const upiUrl = `upi://pay?pa=${upiId}&pn=VATTAM%20Platform&am=${amount}&cu=INR`

  return (
    <main className="min-h-screen pt-24">
      <Navbar />
      <div className="container mx-auto px-4 md:px-8 pb-20 max-w-2xl">
        <Link href="/dashboard" className="inline-flex items-center text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Link>

        <AnimatePresence mode="wait">
          {step === 'input' && (
            <motion.div
              key="input"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="glass border-white/10">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold flex items-center">
                    <Wallet className="w-6 h-6 mr-3 text-primary" />
                    Add Funds to Wallet
                  </CardTitle>
                  <CardDescription>Enter the amount you want to add using Razorpay/UPI</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-muted-foreground">₹</div>
                    <Input 
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="h-16 pl-10 text-3xl font-bold bg-white/5 border-white/10 focus-visible:ring-primary rounded-2xl"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 gap-2">
                    {["100", "500", "1000", "2000"].map((val) => (
                      <Button 
                        key={val} 
                        variant="outline" 
                        onClick={() => setAmount(val)}
                        className="border-white/10 hover:border-primary/50 rounded-xl"
                      >
                        +₹{val}
                      </Button>
                    ))}
                  </div>

                  <Button 
                    onClick={handlePay}
                    disabled={!amount || Number(amount) <= 0}
                    className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 rounded-2xl mt-4"
                  >
                    Proceed to Payment
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === 'payment' && (
            <motion.div
              key="payment"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="glass border-white/10 overflow-hidden">
                <div className="bg-primary/10 p-6 flex items-center justify-between border-b border-white/5">
                  <div>
                    <p className="text-sm text-primary font-medium">Payment for VATTAM Wallet</p>
                    <h3 className="text-3xl font-bold">₹{amount}</h3>
                  </div>
                  <Wallet className="w-10 h-10 text-primary opacity-50" />
                </div>

                <CardContent className="p-8 space-y-8">
                  <div className="flex bg-secondary p-1 rounded-xl">
                    <button 
                      onClick={() => setPaymentMethod('intent')}
                      className={`flex-1 flex items-center justify-center py-3 rounded-lg text-sm font-bold transition-all ${paymentMethod === 'intent' ? 'bg-white/10 text-white' : 'text-muted-foreground'}`}
                    >
                      <Smartphone className="w-4 h-4 mr-2" />
                      App Intent
                    </button>
                    <button 
                      onClick={() => setPaymentMethod('qr')}
                      className={`flex-1 flex items-center justify-center py-3 rounded-lg text-sm font-bold transition-all ${paymentMethod === 'qr' ? 'bg-white/10 text-white' : 'text-muted-foreground'}`}
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      Scan QR
                    </button>
                  </div>

                  <div className="space-y-6 text-center">
                    <p className="text-muted-foreground">Complete payment using your preferred UPI app.</p>
                    <Button 
                      onClick={simulateSuccess} 
                      disabled={isProcessing}
                      className="w-full h-14 bg-emerald-600 hover:bg-emerald-700 rounded-2xl font-bold"
                    >
                      {isProcessing ? <Loader2 className="animate-spin mr-2" /> : null}
                      Verify & Add Funds
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <Card className="glass border-white/10 p-12 space-y-8">
                <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold mb-2">Payment Successful!</h2>
                  <p className="text-muted-foreground">₹{amount} has been added to your wallet.</p>
                </div>
                <Link href="/dashboard" className="block">
                  <Button className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl font-bold text-lg">
                    Return to Dashboard
                  </Button>
                </Link>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <Footer />
    </main>
  )
}
