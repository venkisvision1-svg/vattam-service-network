
"use client"

import React, { useState, useEffect, useRef } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Phone, ArrowRight, ShieldCheck, Languages, Loader2 } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { useAuth, useFirestore } from "@/firebase"
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from "firebase/auth"
import { syncUserProfile } from "@/services/auth-service"

export default function LoginPage() {
  const [step, setStep] = useState<'phone' | 'otp'>('phone')
  const [phoneNumber, setPhoneNumber] = useState("")
  const [otp, setOtp] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const auth = useAuth()
  const db = useFirestore()
  
  const confirmationResultRef = useRef<ConfirmationResult | null>(null)
  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null)

  useEffect(() => {
    if (!recaptchaVerifierRef.current && auth) {
      recaptchaVerifierRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
        'size': 'invisible',
        'callback': () => {
          // reCAPTCHA solved
        }
      });
    }
  }, [auth]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    if (phoneNumber.length < 10) return
    setIsLoading(true)

    const fullPhone = `+91${phoneNumber}`

    try {
      const verifier = recaptchaVerifierRef.current
      if (!verifier) throw new Error("Recaptcha not initialized")

      const result = await signInWithPhoneNumber(auth, fullPhone, verifier)
      confirmationResultRef.current = result
      setStep('otp')
      toast({ title: "OTP Sent", description: "Verification code sent to your mobile." })
    } catch (error: any) {
      console.error(error)
      toast({ 
        variant: "destructive", 
        title: "Error", 
        description: error.message || "Failed to send OTP. Please check your number." 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!confirmationResultRef.current) return
    setIsLoading(true)

    try {
      const credential = await confirmationResultRef.current.confirm(otp)
      const user = credential.user

      // Sync profile to Firestore
      await syncUserProfile(db, user)

      toast({ title: "Login Successful", description: "Welcome back to VATTAM." })
      router.push("/dashboard")
    } catch (error: any) {
      console.error(error)
      toast({ 
        variant: "destructive", 
        title: "Verification Failed", 
        description: "Invalid OTP. Please try again." 
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen pt-24 pb-20">
      <Navbar />
      <div id="recaptcha-container"></div>
      <div className="container mx-auto px-4 md:px-8 max-md">
        <AnimatePresence mode="wait">
          {step === 'phone' ? (
            <motion.div
              key="phone"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-md mx-auto"
            >
              <div className="text-center mb-12">
                <h1 className="font-headline font-bold text-4xl mb-4">வணக்கம்!</h1>
                <p className="text-muted-foreground text-lg">Login to VATTAM Ecosystem</p>
              </div>

              <Card className="glass border-white/10 rounded-[2.5rem] overflow-hidden">
                <CardHeader className="pt-8 pb-4 text-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle>Enter Mobile Number</CardTitle>
                  <CardDescription>We'll send a 6-digit verification code</CardDescription>
                </CardHeader>
                <CardContent className="p-8">
                  <form onSubmit={handleSendOtp} className="space-y-6">
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-bold">+91</span>
                      <Input 
                        type="tel"
                        placeholder="9876543210"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="h-14 pl-14 text-lg bg-white/5 border-white/10 rounded-2xl focus:ring-primary"
                        maxLength={10}
                        required
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl text-lg font-bold"
                      disabled={isLoading || phoneNumber.length < 10}
                    >
                      {isLoading ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : null}
                      {isLoading ? "Sending..." : "Get OTP"} <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </form>

                  <div className="mt-8 pt-8 border-t border-white/5 text-center">
                    <Button variant="ghost" className="text-xs text-muted-foreground hover:text-primary">
                      <Languages className="w-3 h-3 mr-2" /> Switch to தமிழ்
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              key="otp"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-md mx-auto"
            >
              <div className="text-center mb-12">
                <h1 className="font-headline font-bold text-4xl mb-4">Verification</h1>
                <p className="text-muted-foreground text-lg">OTP sent to +91 {phoneNumber}</p>
              </div>

              <Card className="glass border-white/10 rounded-[2.5rem]">
                <CardHeader className="pt-8 pb-4 text-center">
                  <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="w-8 h-8 text-emerald-400" />
                  </div>
                  <CardTitle>Verify OTP</CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <form onSubmit={handleVerifyOtp} className="space-y-6">
                    <Input 
                      type="text"
                      placeholder="000000"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      className="h-16 text-center text-3xl font-bold tracking-[1em] bg-white/5 border-white/10 rounded-2xl"
                      maxLength={6}
                      required
                    />
                    <Button 
                      type="submit" 
                      className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl text-lg font-bold"
                      disabled={isLoading || otp.length < 6}
                    >
                      {isLoading ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : null}
                      {isLoading ? "Verifying..." : "Verify & Login"}
                    </Button>
                  </form>
                  <Button 
                    variant="link" 
                    className="w-full mt-4 text-muted-foreground"
                    onClick={() => setStep('phone')}
                  >
                    Change Number
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <Footer />
    </main>
  )
}
