
import { Navbar } from "@/components/layout/Navbar"
import { Hero } from "@/components/home/Hero"
import { CategoryGrid } from "@/components/home/CategoryGrid"
import { FeaturedSection } from "@/components/home/FeaturedSection"
import { QRHub } from "@/components/home/QRHub"
import { Footer } from "@/components/layout/Footer"

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      <Navbar />
      <Hero />
      <CategoryGrid />
      <FeaturedSection />
      <QRHub />
      <Footer />
    </main>
  )
}
