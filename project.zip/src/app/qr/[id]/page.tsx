
"use client"

import React, { useEffect, useMemo } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageSquare, Share2, MapPin, Globe, ExternalLink, Instagram, Linkedin, Twitter, Loader2 } from "lucide-react"
import Image from "next/image"
import { useParams } from "next/navigation"
import { useFirestore, useDoc } from "@/firebase"
import { doc } from "firebase/firestore"
import { trackQRScan } from "@/services/qr-service"
import { QRCodeSVG } from "qrcode.react"

export default function QRProfilePage() {
  const params = useParams()
  const qrId = params.id as string
  const db = useFirestore()

  const qrRef = useMemo(() => {
    if (!qrId || !db) return null
    return doc(db, 'qr_profiles', qrId)
  }, [qrId, db])

  const { data: profile, loading } = useDoc(qrRef)

  useEffect(() => {
    if (qrId && db) {
      trackQRScan(db, qrId)
    }
  }, [qrId, db])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin h-12 w-12 text-primary" />
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center space-y-4">
        <h2 className="text-2xl font-bold">QR Profile Not Found</h2>
        <Button onClick={() => window.location.href = '/'}>Back to Home</Button>
      </div>
    )
  }

  return (
    <main className="min-h-screen pt-24 pb-20 bg-gradient-to-b from-primary/10 to-background">
      <Navbar />
      <div className="container mx-auto px-4 md:px-8 max-w-2xl">
        <div className="relative mb-24">
          <div className="h-48 w-full rounded-[2.5rem] bg-secondary border border-white/10 overflow-hidden relative">
            <Image src="https://picsum.photos/seed/biz-cover/1000/400" alt="Cover" fill className="object-cover opacity-50" />
          </div>
          <div className="absolute -bottom-16 left-1/2 -translate-x-1/2">
            <div className="w-32 h-32 rounded-full border-8 border-background bg-secondary overflow-hidden orange-glow flex items-center justify-center">
               <Image src="https://picsum.photos/seed/biz-logo/200/200" alt="Logo" fill className="object-cover" />
            </div>
          </div>
        </div>

        <div className="text-center space-y-6 mb-12">
          <h1 className="font-headline font-bold text-4xl">{profile.businessName}</h1>
          <p className="text-primary font-bold uppercase tracking-[0.2em] text-xs">VATTAM Verified Business</p>
          <div className="flex items-center justify-center text-muted-foreground text-sm">
            <MapPin className="w-4 h-4 mr-1" /> Coimbatore, Tamil Nadu
          </div>
          
          <div className="flex justify-center gap-4">
            <div className="p-4 bg-white rounded-2xl">
              <QRCodeSVG value={`https://vattams.net/qr/${qrId}`} size={120} />
            </div>
          </div>
        </div>

        <Card className="glass border-white/10 rounded-[2.5rem] p-8 mb-8">
          <CardContent className="p-0 space-y-8 text-center">
            <div className="space-y-2">
              <h3 className="font-bold text-xl">Contact Information</h3>
              <p className="text-muted-foreground text-sm">
                Instant networking for service professionals in Tamil Nadu.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <a href={`https://wa.me/${profile.whatsappNumber}`} className="flex-1">
                <Button className="w-full h-16 bg-emerald-600 hover:bg-emerald-700 rounded-2xl text-lg font-bold">
                  <MessageSquare className="w-6 h-6 mr-2" /> WhatsApp
                </Button>
              </a>
              <Button variant="outline" className="h-16 border-white/10 rounded-2xl text-lg font-bold">
                <Share2 className="w-6 h-6 mr-2" /> Share Card
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-16 text-center">
          <p className="text-xs text-muted-foreground mb-4">Powered by</p>
          <div className="inline-flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center font-headline font-bold text-white text-xs italic">V</div>
            <span className="font-headline font-bold tracking-tighter">VATTAM</span>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
