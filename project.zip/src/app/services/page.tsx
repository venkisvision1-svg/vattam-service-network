"use client"

import React from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { CategoryGrid } from "@/components/home/CategoryGrid"
import { Input } from "@/components/ui/input"
import { Search, MapPin, Filter } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

const allServices = [
  { id: 1, name: "AC Deep Cleaning", price: "₹599", time: "60 mins", img: "https://picsum.photos/seed/service1/400/300" },
  { id: 2, name: "CCTV Installation", price: "₹1,299", time: "120 mins", img: "https://picsum.photos/seed/service2/400/300" },
  { id: 3, name: "Electrical Repair", price: "₹199", time: "30 mins", img: "https://picsum.photos/seed/service3/400/300" },
  { id: 4, name: "Home Painting", price: "₹2,499", time: "Full day", img: "https://picsum.photos/seed/service4/400/300" },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen pt-24 pb-20">
      <Navbar />
      
      {/* Search Header */}
      <div className="container mx-auto px-4 md:px-8 mb-12">
        <div className="flex flex-col space-y-6">
          <h1 className="font-headline font-bold text-4xl">Search Services</h1>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                placeholder="What are you looking for?" 
                className="h-14 pl-12 bg-white/5 border-white/10 rounded-2xl"
              />
            </div>
            <Button variant="outline" className="h-14 w-14 rounded-2xl border-white/10 bg-white/5">
              <Filter className="w-5 h-5" />
            </Button>
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="w-4 h-4 mr-1 text-primary" />
            Serving in <span className="text-white font-medium ml-1">Chennai, Tamil Nadu</span>
          </div>
        </div>
      </div>

      <CategoryGrid />

      {/* Recommended Services */}
      <div className="container mx-auto px-4 md:px-8 mt-12">
        <h2 className="font-headline font-bold text-2xl mb-8">Recommended for You</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {allServices.map((service) => (
            <Link key={service.id} href="/booking">
              <Card className="premium-card p-0 overflow-hidden group">
                <div className="relative h-48 w-full">
                  <Image 
                    src={service.img} 
                    alt={service.name} 
                    fill 
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-primary">
                    {service.price}
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2">{service.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{service.time}</span>
                    <Button size="sm" className="rounded-xl h-8 text-xs font-bold">Book Now</Button>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      <Footer />
    </main>
  )
}
