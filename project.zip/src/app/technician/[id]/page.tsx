"use client"

import React from "react"
import { Navbar } from "@/components/layout/Navbar"
import { Footer } from "@/components/layout/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, MapPin, ShieldCheck, Clock, Award, MessageSquare, Phone } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function TechnicianProfile({ params }: { params: { id: string } }) {
  return (
    <main className="min-h-screen pt-24 pb-20">
      <Navbar />
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-5xl mx-auto">
          {/* Header Profile */}
          <div className="flex flex-col md:flex-row gap-12 items-center md:items-start mb-16">
            <div className="relative w-48 h-48 md:w-64 md:h-64 rounded-[3rem] overflow-hidden orange-glow">
              <Image 
                src="https://picsum.photos/seed/tech-profile/600/600" 
                alt="Profile" 
                fill 
                className="object-cover"
              />
              <div className="absolute top-6 right-6 bg-primary p-2 rounded-2xl border-4 border-background">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <div className="inline-flex items-center px-4 py-1.5 rounded-full glass border-white/10 mb-6 text-xs font-bold uppercase tracking-widest text-primary">
                Verified Expert Professional
              </div>
              <h1 className="font-headline font-bold text-5xl mb-4 tracking-tight">Ramesh Kumar</h1>
              <p className="text-xl text-muted-foreground mb-8">Master Electrician & Smart Home Specialist</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-8 mb-10">
                <div className="text-center">
                  <p className="text-3xl font-bold">4.9</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-tighter">Rating</p>
                </div>
                <div className="h-10 w-px bg-white/10"></div>
                <div className="text-center">
                  <p className="text-3xl font-bold">1.2k</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-tighter">Jobs Done</p>
                </div>
                <div className="h-10 w-px bg-white/10"></div>
                <div className="text-center">
                  <p className="text-3xl font-bold">8yrs</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-tighter">Experience</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/booking" className="flex-1">
                  <Button className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl text-lg font-bold">
                    Book for Service
                  </Button>
                </Link>
                <Button variant="outline" className="flex-1 h-14 border-white/10 rounded-2xl">
                  <Phone className="w-5 h-5 mr-2" /> WhatsApp
                </Button>
              </div>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <Card className="glass border-white/10 rounded-[2.5rem] p-10">
                <h3 className="font-headline font-bold text-2xl mb-6">About Professional</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Specializing in complex residential and commercial electrical systems. Certified by VATTAM Academy with top scores in safety and efficiency. Known for punctual arrivals and clean professional work.
                </p>
                <div className="grid sm:grid-cols-2 gap-6 mt-10">
                  <div className="flex items-center p-4 rounded-2xl bg-white/5">
                    <Clock className="w-6 h-6 text-primary mr-4" />
                    <div>
                      <p className="font-bold">Fast Response</p>
                      <p className="text-xs text-muted-foreground">Arrives within 45 mins</p>
                    </div>
                  </div>
                  <div className="flex items-center p-4 rounded-2xl bg-white/5">
                    <Award className="w-6 h-6 text-primary mr-4" />
                    <div>
                      <p className="font-bold">Certified Pro</p>
                      <p className="text-xs text-muted-foreground">Government Licensed</p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="glass border-white/10 rounded-[2.5rem] p-10">
                <h3 className="font-headline font-bold text-2xl mb-8">Recent Work Photos</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {[1,2,3,4,5,6].map(i => (
                    <div key={i} className="relative aspect-square rounded-2xl overflow-hidden group">
                      <Image 
                        src={`https://picsum.photos/seed/work${i}/400/400`} 
                        alt="Work" 
                        fill 
                        className="object-cover group-hover:scale-110 transition-transform"
                      />
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <div className="space-y-8">
              <Card className="glass border-white/10 rounded-[2.5rem] p-8">
                <h3 className="font-headline font-bold text-xl mb-6">Verified Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {["Fan Repair", "Switchboard", "Smart Lighting", "Wiring", "AC Electrical", "Panel Fix"].map(skill => (
                    <span key={skill} className="px-3 py-1 bg-white/5 rounded-lg text-xs font-medium border border-white/5">
                      {skill}
                    </span>
                  ))}
                </div>
              </Card>
              
              <Card className="glass border-white/10 rounded-[2.5rem] p-8">
                <h3 className="font-headline font-bold text-xl mb-6">Reviews</h3>
                <div className="space-y-6">
                  {[1,2,3].map(i => (
                    <div key={i} className="border-b border-white/5 pb-4 last:border-0">
                      <div className="flex items-center space-x-2 mb-2">
                        <Star className="w-3 h-3 text-primary fill-primary" />
                        <Star className="w-3 h-3 text-primary fill-primary" />
                        <Star className="w-3 h-3 text-primary fill-primary" />
                        <Star className="w-3 h-3 text-primary fill-primary" />
                        <Star className="w-3 h-3 text-primary fill-primary" />
                      </div>
                      <p className="text-sm text-muted-foreground italic">"Excellent service, very professional and polite. Fixed my issue in 20 mins."</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
