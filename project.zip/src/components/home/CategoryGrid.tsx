
"use client"

import React from "react"
import { 
  Wind, Tv, Droplets, Zap, Shield, Home, Sun, 
  Smartphone, QrCode, Monitor, Laptop, Hammer 
} from "lucide-react"
import { motion } from "framer-motion"

const categories = [
  { name: "AC Service", icon: Wind, color: "text-blue-400" },
  { name: "Refrigerator", icon: Laptop, color: "text-indigo-400" },
  { name: "Washing Machine", icon: Monitor, color: "text-purple-400" },
  { name: "Plumbing", icon: Droplets, color: "text-sky-400" },
  { name: "Electrician", icon: Zap, color: "text-yellow-400" },
  { name: "CCTV", icon: Shield, color: "text-red-400" },
  { name: "RO Service", icon: Droplets, color: "text-blue-300" },
  { name: "Painting", icon: Home, color: "text-orange-400" },
  { name: "Solar", icon: Sun, color: "text-amber-400" },
  { name: "Marketing", icon: Smartphone, color: "text-pink-400" },
  { name: "QR Setup", icon: QrCode, color: "text-emerald-400" },
  { name: "Handyman", icon: Hammer, color: "text-slate-400" },
]

export const CategoryGrid = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 space-y-4 md:space-y-0">
          <div>
            <h2 className="font-headline font-bold text-4xl mb-4">Popular Categories</h2>
            <p className="text-muted-foreground">Most requested services in your neighborhood</p>
          </div>
          <button className="text-primary font-medium hover:underline flex items-center">
            View all services
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {categories.map((cat, idx) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05 }}
              className="group glass p-6 rounded-3xl border-white/5 hover:border-primary/30 transition-all cursor-pointer text-center"
            >
              <div className="mb-4 inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/5 group-hover:bg-primary/10 transition-colors">
                <cat.icon className={`w-7 h-7 ${cat.color} group-hover:scale-110 transition-transform`} />
              </div>
              <h3 className="text-sm font-semibold tracking-tight">{cat.name}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
