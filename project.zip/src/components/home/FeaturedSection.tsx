
"use client"

import React from "react"
import Image from "next/image"
import { Star, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { motion } from "framer-motion"

const featuredTechnicians = [
  {
    id: 1,
    name: "Ramesh Kumar",
    service: "Expert Electrician",
    rating: 4.9,
    reviews: 124,
    location: "Adyar, Chennai",
    img: "https://picsum.photos/seed/tech1/200/200"
  },
  {
    id: 2,
    name: "Senthil Nathan",
    service: "AC Specialist",
    rating: 4.8,
    reviews: 89,
    location: "T-Nagar, Chennai",
    img: "https://picsum.photos/seed/tech2/200/200"
  },
  {
    id: 3,
    name: "Priya Dharshini",
    service: "Solar Consultant",
    rating: 5.0,
    reviews: 56,
    location: "Velachery, Chennai",
    img: "https://picsum.photos/seed/tech3/200/200"
  }
]

export const FeaturedSection = () => {
  return (
    <section className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="font-headline font-bold text-4xl md:text-5xl mb-8">
              Work with the Best <br />
              <span className="text-primary">Verified Professionals</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Every technician on VATTAM undergoes a rigorous background check and skill assessment. 
              We ensure premium quality and reliability for every booking.
            </p>
            
            <ul className="space-y-6 mb-12">
              {[
                "Background verified technicians",
                "Upfront transparent pricing",
                "Service warranty included",
                "24/7 Priority support"
              ].map((item, i) => (
                <li key={i} className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  </div>
                  <span className="font-medium">{item}</span>
                </li>
              ))}
            </ul>

            <Button className="bg-primary hover:bg-primary/90 px-8 h-12 rounded-xl">
              Become a Technician
            </Button>
          </div>

          <div className="space-y-6">
            {featuredTechnicians.map((tech, idx) => (
              <motion.div
                key={tech.id}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="glass p-6 rounded-3xl border-white/5 flex items-center space-x-6 hover:border-primary/20 transition-all group"
              >
                <div className="relative w-20 h-20 flex-shrink-0">
                  <Image 
                    src={tech.img} 
                    alt={tech.name} 
                    fill 
                    className="object-cover rounded-2xl grayscale group-hover:grayscale-0 transition-all"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-lg">{tech.name}</h3>
                      <p className="text-primary text-sm font-medium">{tech.service}</p>
                    </div>
                    <div className="flex items-center bg-white/5 px-2 py-1 rounded-lg">
                      <Star className="w-3 h-3 text-primary fill-primary mr-1" />
                      <span className="text-xs font-bold">{tech.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 mt-3 text-muted-foreground">
                    <div className="flex items-center text-xs">
                      <MapPin className="w-3 h-3 mr-1" />
                      {tech.location}
                    </div>
                    <div className="flex items-center text-xs">
                      <Clock className="w-3 h-3 mr-1" />
                      Available Now
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
