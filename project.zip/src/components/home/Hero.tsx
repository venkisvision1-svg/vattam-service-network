
"use client"

import React, { useState } from "react"
import { Search, Mic, MapPin, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { intelligentServiceSearch } from "@/ai/flows/intelligent-service-search"
import { useToast } from "@/hooks/use-toast"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import Image from "next/image"

export const Hero = () => {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const { toast } = useToast()

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!query.trim()) return

    setIsSearching(true)
    try {
      const result = await intelligentServiceSearch({
        query,
        userLocation: "Chennai, Tamil Nadu",
        preferredLanguage: "en"
      })
      
      toast({
        title: `Found: ${result.serviceCategory}`,
        description: result.technicianAvailability,
      })
      // Here you would typically route to the service page
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Search Failed",
        description: "Could not process your request. Please try again.",
      })
    } finally {
      setIsSearching(false)
    }
  }

  const heroImage = PlaceHolderImages.find(img => img.id === "hero-bg")

  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <Image 
          src={heroImage?.imageUrl || ""} 
          alt="VATTAM Hero" 
          fill 
          className="object-cover opacity-20"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
      </div>

      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full glass border-white/10 mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium tracking-wide">Tamil Nadu's #1 Service Ecosystem</span>
          </div>

          <h1 className="font-headline font-bold text-5xl md:text-7xl lg:text-8xl tracking-tight mb-6 leading-[1.1] animate-in fade-in slide-in-from-bottom-6 duration-700">
            Smart Services, <br />
            <span className="text-gradient">Tamil Nadu Style.</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-900">
            From expert AC repairs to solar installation and digital networking, 
            VATTAM connects you with trusted local professionals in seconds.
          </p>

          <form 
            onSubmit={handleSearch}
            className="relative max-w-2xl mx-auto group animate-in fade-in slide-in-from-bottom-10 duration-1000"
          >
            <div className="glass p-2 rounded-2xl flex items-center shadow-2xl border-white/20 focus-within:ring-2 ring-primary/50 transition-all">
              <div className="hidden sm:flex items-center px-4 border-r border-white/10 mr-2 text-muted-foreground whitespace-nowrap">
                <MapPin className="w-4 h-4 mr-2 text-primary" />
                <span className="text-xs font-medium">Chennai</span>
              </div>
              <div className="relative flex-1 flex items-center">
                <Search className="absolute left-4 w-5 h-5 text-muted-foreground" />
                <Input 
                  placeholder="Need a plumber? or AC repair?" 
                  className="bg-transparent border-0 focus-visible:ring-0 pl-12 h-12 text-lg"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
              <Button 
                type="button" 
                size="icon" 
                variant="ghost" 
                className="text-primary hover:text-primary hover:bg-primary/10"
              >
                <Mic className="w-5 h-5" />
              </Button>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90 ml-2 rounded-xl px-8 h-12"
                disabled={isSearching}
              >
                {isSearching ? "Finding..." : "Search"}
              </Button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              Try: "AC service in Anna Nagar" or "வீடு பெயிண்டிங்"
            </p>
          </form>
        </div>
      </div>
    </section>
  )
}
