"use client"

import React from "react"
import { QrCode, Smartphone, Share2, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export const QRHub = () => {
  const qrImage = PlaceHolderImages.find(img => img.id === "qr-business")

  return (
    <section className="py-24 overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="glass p-12 md:p-20 rounded-[3rem] border-white/10 relative overflow-hidden">
          {/* Decorative background blobs */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="grid lg:grid-cols-2 gap-16 items-center relative z-10">
            <div>
              <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
                <QrCode className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Digital QR Hub</span>
              </div>
              
              <h2 className="font-headline font-bold text-4xl md:text-6xl mb-8 tracking-tight">
                Revolutionize Your <br />
                <span className="text-gradient">Business Profile</span>
              </h2>
              
              <p className="text-lg text-muted-foreground mb-12">
                Generate a unique QR profile for your service or business. 
                Share it with clients, track analytics, and integrate directly with WhatsApp for instant inquiries.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-8 mb-12">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Smartphone className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Mobile First</h4>
                    <p className="text-sm text-muted-foreground">Optimized for quick mobile viewing.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <Share2 className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Instant Share</h4>
                    <p className="text-sm text-muted-foreground">Share via WhatsApp, SMS, or Socials.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Analytics</h4>
                    <p className="text-sm text-muted-foreground">Track who's viewing your business profile.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <QrCode className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Custom QR</h4>
                    <p className="text-sm text-muted-foreground">Branded QR codes for your storefront.</p>
                  </div>
                </div>
              </div>
              
              <Button className="bg-primary hover:bg-primary/90 px-10 h-14 rounded-2xl text-lg font-bold">
                Create My Business QR
              </Button>
            </div>
            
            <div className="relative group">
              <div className="absolute inset-0 bg-primary/20 blur-[100px] group-hover:bg-primary/30 transition-all rounded-full"></div>
              <div className="relative glass p-4 rounded-[2.5rem] rotate-3 group-hover:rotate-0 transition-all duration-700">
                <Image 
                  src={qrImage?.imageUrl || ""} 
                  alt="QR Networking" 
                  width={600} 
                  height={800} 
                  className="rounded-[2rem] object-cover"
                />
                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 glass px-6 py-4 rounded-2xl border-white/20 shadow-2xl flex items-center space-x-4 min-w-[280px]">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Scan for business card</p>
                    <p className="font-bold">vattams.net/biz/technician-01</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
