"use client"

import React from "react"
import Link from "next/link"
import Image from "next/image"
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export const Footer = () => {
  const logoImage = PlaceHolderImages.find(img => img.id === "app-logo")

  return (
    <footer className="bg-secondary/20 pt-20 pb-10 border-t border-white/5">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-6">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center bg-black">
                {logoImage ? (
                  <Image 
                    src={logoImage.imageUrl} 
                    alt="VATTAM Logo" 
                    fill 
                    className="object-cover"
                  />
                ) : (
                  <span className="font-headline font-bold text-white text-xl">V</span>
                )}
              </div>
              <span className="font-headline font-bold text-2xl tracking-tighter">VATTAM</span>
            </Link>
            <p className="text-muted-foreground">
              Tamil Nadu's premium service ecosystem connecting high-end technicians with smart consumers. 
              Modernizing local services through AI and digital networking.
            </p>
            <div className="flex items-center space-x-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
                <Link key={i} href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {["Find a Service", "QR Networking", "Join as Technician", "Vendor Panel", "Wallet & Earning"].map((link) => (
                <li key={link}>
                  <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">{link}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6">Services</h4>
            <ul className="space-y-4">
              {["AC & Cooling", "Electrical Works", "Smart Home & CCTV", "Solar Solutions", "Digital Business Setup"].map((link) => (
                <li key={link}>
                  <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">{link}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-muted-foreground">
                <MapPin className="w-5 h-5 text-primary shrink-0" />
                <span>Anna Salai, Little Mount, Chennai, Tamil Nadu 600015</span>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <Phone className="w-5 h-5 text-primary shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <Mail className="w-5 h-5 text-primary shrink-0" />
                <span>support@vattams.net</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} VATTAM Platform. All rights reserved. Made in Tamil Nadu.
          </p>
          <div className="flex space-x-8 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-primary">Privacy Policy</Link>
            <Link href="#" className="hover:text-primary">Terms of Service</Link>
            <Link href="#" className="hover:text-primary">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
