"use client"

import React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, Calendar, User, QrCode } from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { name: "Home", icon: Home, href: "/" },
  { name: "Services", icon: Search, href: "/services" },
  { name: "QR", icon: QrCode, href: "/dashboard" },
  { name: "Bookings", icon: Calendar, href: "/bookings" },
  { name: "Profile", icon: User, href: "/dashboard" },
]

export const MobileNav = () => {
  const pathname = usePathname()

  return (
    <nav className="mobile-bottom-nav">
      {navItems.map((item) => {
        const isActive = pathname === item.href
        return (
          <Link
            key={item.name}
            href={item.href}
            className={cn(
              "flex flex-col items-center space-y-1 transition-all duration-300",
              isActive ? "text-primary scale-110" : "text-muted-foreground"
            )}
          >
            <item.icon className={cn("w-6 h-6", isActive && "fill-primary/10")} />
            <span className="text-[10px] font-medium">{item.name}</span>
          </Link>
        )
      })}
    </nav>
  )
}
