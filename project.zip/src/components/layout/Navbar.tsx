
"use client"

import React, { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Bell, User, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const logoImage = PlaceHolderImages.find(img => img.id === "app-logo")

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "py-2 glass border-b border-white/10" : "py-4 bg-transparent"
      )}
    >
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <div className="relative w-10 h-10 rounded-xl overflow-hidden orange-glow flex items-center justify-center bg-black">
              {logoImage ? (
                <Image 
                  src={logoImage.imageUrl} 
                  alt="VATTAM Logo" 
                  fill 
                  className="object-cover"
                />
              ) : (
                <span className="font-headline font-bold text-white text-xl">V</span>
              )}
            </div>
            <span className="font-headline font-bold text-2xl tracking-tighter hidden sm:block">VATTAM</span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link href="/services" className="text-sm font-medium hover:text-primary transition-colors">Services</Link>
            <Link href="/qr-network" className="text-sm font-medium hover:text-primary transition-colors">QR Network</Link>
            <Link href="/bookings" className="text-sm font-medium hover:text-primary transition-colors">My Bookings</Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden sm:flex items-center space-x-1 text-muted-foreground mr-4">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium">Chennai, TN</span>
            </div>
            
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-accent rounded-full border-2 border-background"></span>
            </Button>
            
            <Link href="/dashboard">
              <Button className="bg-primary hover:bg-primary/90 rounded-full px-6">
                <User className="w-4 h-4 mr-2" />
                Login
              </Button>
            </Link>

            <button 
              className="md:hidden p-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 glass border-b border-white/10 p-4 animate-in slide-in-from-top duration-300">
          <div className="flex flex-col space-y-4">
            <Link href="/services" className="px-4 py-2 hover:bg-primary/10 rounded-lg" onClick={() => setIsMobileMenuOpen(false)}>Services</Link>
            <Link href="/qr-network" className="px-4 py-2 hover:bg-primary/10 rounded-lg" onClick={() => setIsMobileMenuOpen(false)}>QR Network</Link>
            <Link href="/bookings" className="px-4 py-2 hover:bg-primary/10 rounded-lg" onClick={() => setIsMobileMenuOpen(false)}>My Bookings</Link>
            <Link href="/dashboard" className="px-4 py-2 hover:bg-primary/10 rounded-lg" onClick={() => setIsMobileMenuOpen(false)}>Dashboard</Link>
          </div>
        </div>
      )}
    </nav>
  )
}
