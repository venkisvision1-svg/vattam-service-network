"use client"

import React from "react"
import Image from "next/image"
import { Star, MapPin, ShieldCheck, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

interface TechProps {
  id: string | number
  name: string
  service: string
  rating: number
  experience: string
  location: string
  img: string
}

export const TechnicianCard = ({ id, name, service, rating, experience, location, img }: TechProps) => {
  return (
    <Link href={`/technician/${id}`}>
      <Card className="premium-card p-4 flex gap-4 group">
        <div className="relative w-24 h-24 shrink-0">
          <Image 
            src={img} 
            alt={name} 
            fill 
            className="object-cover rounded-2xl grayscale group-hover:grayscale-0 transition-all duration-500"
          />
          <div className="absolute -bottom-1 -right-1 bg-primary p-1 rounded-lg border-2 border-background">
            <ShieldCheck className="w-3 h-3 text-white" />
          </div>
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold">{name}</h3>
              <p className="text-primary text-xs font-bold uppercase tracking-wider">{service}</p>
            </div>
            <div className="flex items-center space-x-1 bg-white/5 px-2 py-0.5 rounded-lg border border-white/5">
              <Star className="w-3 h-3 text-primary fill-primary" />
              <span className="text-xs font-bold">{rating}</span>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-3 text-muted-foreground text-[10px] font-medium uppercase tracking-widest">
            <span className="flex items-center"><MapPin className="w-3 h-3 mr-1" /> {location}</span>
            <span className="h-1 w-1 bg-muted-foreground rounded-full"></span>
            <span>{experience} Exp</span>
          </div>
          <div className="mt-3 flex justify-end">
            <ArrowRight className="w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-all" />
          </div>
        </div>
      </Card>
    </Link>
  )
}
