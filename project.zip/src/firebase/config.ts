'use client';

/**
 * Firebase client configuration using environment variables.
 * NEXT_PUBLIC_ prefix is required for these to be accessible in the browser.
 */
export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY?.trim(),
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN?.trim(),
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID?.trim(),
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET?.trim(),
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID?.trim(),
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID?.trim(),
};

// Validation logic to help developers identify missing config
if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
  const missingKeys = Object.entries(firebaseConfig)
    .filter(([key, value]) => !value || value === 'undefined')
    .map(([key]) => key);

  if (missingKeys.length > 0) {
    console.warn(
      `Firebase Configuration Warning: Missing or invalid environment variables: ${missingKeys.join(', ')}. 
      Please ensure you have a .env file with the correct NEXT_PUBLIC_FIREBASE_* values.`
    );
  }
}
