'use client';

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { firebaseConfig } from './config';

/**
 * Initializes Firebase services safely.
 * Returns null for services if config is invalid to prevent application-wide crashes.
 */
export function initializeFirebase() {
  // Check for valid API key and project ID to avoid SDK initialization errors
  const isConfigValid = 
    firebaseConfig.apiKey && 
    firebaseConfig.apiKey !== 'undefined' &&
    firebaseConfig.projectId &&
    firebaseConfig.projectId !== 'undefined';

  if (!isConfigValid) {
    return { 
      app: null as any as FirebaseApp, 
      db: null as any as Firestore, 
      auth: null as any as Auth 
    };
  }

  try {
    const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    const db = getFirestore(app);
    const auth = getAuth(app);

    return { app, db, auth };
  } catch (error) {
    console.error('Firebase Initialization Error:', error);
    return { 
      app: null as any as FirebaseApp, 
      db: null as any as Firestore, 
      auth: null as any as Auth 
    };
  }
}

export * from './provider';
export * from './auth/use-user';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
