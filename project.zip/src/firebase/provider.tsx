'use client';

import React, { createContext, useContext } from 'react';
import { FirebaseApp } from 'firebase/app';
import { Firestore } from 'firebase/firestore';
import { Auth } from 'firebase/auth';

interface FirebaseContextType {
  app: FirebaseApp | null;
  db: Firestore | null;
  auth: Auth | null;
}

const FirebaseContext = createContext<FirebaseContextType | null>(null);

export const FirebaseProvider: React.FC<{
  app: FirebaseApp | null;
  db: Firestore | null;
  auth: Auth | null;
  children: React.ReactNode;
}> = ({ app, db, auth, children }) => {
  return (
    <FirebaseContext.Provider value={{ app, db, auth }}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (!context) return { app: null, db: null, auth: null };
  return context;
};

export const useFirestore = () => useFirebase().db!;
export const useAuth = () => useFirebase().auth!;
export const useFirebaseApp = () => useFirebase().app!;
