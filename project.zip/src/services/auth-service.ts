
'use client';

import { 
  Firestore, 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Ensures a user profile exists in Firestore after OTP login.
 */
export async function syncUserProfile(db: Firestore, user: any, role: string = 'customer') {
  const userRef = doc(db, 'users', user.uid);
  
  try {
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) {
      const profileData = {
        uid: user.uid,
        phoneNumber: user.phoneNumber,
        role: role,
        displayName: user.displayName || `VATTAM User ${user.phoneNumber?.slice(-4)}`,
        createdAt: serverTimestamp(),
        isActive: true,
        lastLoginAt: serverTimestamp()
      };

      setDoc(userRef, profileData).catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: `users/${user.uid}`,
          operation: 'create',
          requestResourceData: profileData,
        });
        errorEmitter.emit('permission-error', permissionError);
      });

      // Initialize empty wallet
      const walletRef = doc(db, 'wallets', user.uid);
      setDoc(walletRef, {
        uid: user.uid,
        balance: 0,
        totalEarnings: 0,
        currency: 'INR'
      });
    } else {
      // Update last login
      setDoc(userRef, { lastLoginAt: serverTimestamp() }, { merge: true });
    }
  } catch (error) {
    console.error("Error syncing user profile:", error);
  }
}

/**
 * Updates a user's role (Admin only logic usually handled by Firestore Rules)
 */
export function updateUserRole(db: Firestore, uid: string, role: string) {
  const userRef = doc(db, 'users', uid);
  setDoc(userRef, { role }, { merge: true }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `users/${uid}`,
      operation: 'update',
      requestResourceData: { role },
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}
