
'use client';

import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  serverTimestamp, 
  Firestore 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Create a new service booking.
 */
export function createBooking(db: Firestore, bookingData: any) {
  const bookingsRef = collection(db, 'bookings');
  
  const newBooking = {
    ...bookingData,
    status: 'pending',
    paymentStatus: 'unpaid',
    createdAt: serverTimestamp(),
  };

  addDoc(bookingsRef, newBooking).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: 'bookings',
      operation: 'create',
      requestResourceData: newBooking,
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}

/**
 * Assign a technician to a booking.
 */
export function assignTechnician(db: Firestore, bookingId: string, technicianId: string) {
  const bookingRef = doc(db, 'bookings', bookingId);
  
  updateDoc(bookingRef, {
    technicianId,
    status: 'assigned',
    assignedAt: serverTimestamp(),
  }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `bookings/${bookingId}`,
      operation: 'update',
      requestResourceData: { technicianId, status: 'assigned' },
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}

/**
 * Update the status of a booking (e.g., ongoing, completed, cancelled).
 */
export function updateBookingStatus(db: Firestore, bookingId: string, status: string) {
  const bookingRef = doc(db, 'bookings', bookingId);
  
  updateDoc(bookingRef, {
    status,
    updatedAt: serverTimestamp(),
  }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `bookings/${bookingId}`,
      operation: 'update',
      requestResourceData: { status },
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}
