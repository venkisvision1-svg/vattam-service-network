
'use client';

import { 
  Firestore, 
  collection, 
  addDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Sends an in-app notification to a user.
 */
export function sendNotification(db: Firestore, userId: string, title: string, message: string) {
  const notificationsRef = collection(db, 'notifications');
  
  const notificationData = {
    userId,
    title,
    message,
    isRead: false,
    createdAt: serverTimestamp(),
  };

  addDoc(notificationsRef, notificationData).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: 'notifications',
      operation: 'create',
      requestResourceData: notificationData,
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}
