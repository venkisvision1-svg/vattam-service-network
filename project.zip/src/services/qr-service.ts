
'use client';

import { 
  Firestore, 
  doc, 
  setDoc, 
  updateDoc, 
  increment, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Setup or update a business QR profile.
 */
export function updateQRProfile(db: Firestore, qrId: string, data: any) {
  const qrRef = doc(db, 'qr_profiles', qrId);
  
  setDoc(qrRef, {
    ...data,
    qrId,
    updatedAt: serverTimestamp(),
  }, { merge: true }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `qr_profiles/${qrId}`,
      operation: 'write',
      requestResourceData: data,
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}

/**
 * Track a QR scan event.
 */
export function trackQRScan(db: Firestore, qrId: string) {
  const qrRef = doc(db, 'qr_profiles', qrId);
  
  updateDoc(qrRef, {
    scansCount: increment(1)
  }).catch(async (err) => {
    // Silent fail for background tracking
  });
}
