
'use client';

import { 
  Firestore, 
  doc, 
  setDoc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Register or update technician professional details.
 */
export function updateTechnicianProfile(db: Firestore, uid: string, data: any) {
  const techRef = doc(db, 'technicians', uid);
  
  setDoc(techRef, {
    ...data,
    uid,
    updatedAt: serverTimestamp(),
  }, { merge: true }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `technicians/${uid}`,
      operation: 'write',
      requestResourceData: data,
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}

/**
 * Toggle technician availability for new jobs.
 */
export function setAvailability(db: Firestore, uid: string, isAvailable: boolean) {
  const techRef = doc(db, 'technicians', uid);
  
  updateDoc(techRef, { isAvailable }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `technicians/${uid}`,
      operation: 'update',
      requestResourceData: { isAvailable },
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}

/**
 * Admin: Approve or Reject a technician.
 */
export function verifyTechnician(db: Firestore, uid: string, status: 'verified' | 'rejected') {
  const techRef = doc(db, 'technicians', uid);
  
  updateDoc(techRef, { verificationStatus: status }).catch(async (err) => {
    const permissionError = new FirestorePermissionError({
      path: `technicians/${uid}`,
      operation: 'update',
      requestResourceData: { verificationStatus: status },
    });
    errorEmitter.emit('permission-error', permissionError);
  });
}
