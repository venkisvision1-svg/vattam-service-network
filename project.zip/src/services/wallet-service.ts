
'use client';

import { 
  Firestore, 
  doc, 
  collection, 
  addDoc, 
  runTransaction, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Records a transaction and updates the wallet balance atomically.
 */
export async function processTransaction(
  db: Firestore, 
  uid: string, 
  amount: number, 
  type: 'credit' | 'debit',
  description: string
) {
  const walletRef = doc(db, 'wallets', uid);
  const transactionsRef = collection(db, 'wallets', uid, 'transactions');

  try {
    await runTransaction(db, async (transaction) => {
      const walletDoc = await transaction.get(walletRef);
      if (!walletDoc.exists()) {
        throw new Error("Wallet does not exist!");
      }

      const currentBalance = walletDoc.data().balance || 0;
      const newBalance = type === 'credit' ? currentBalance + amount : currentBalance - amount;

      if (newBalance < 0) {
        throw new Error("Insufficient balance");
      }

      transaction.update(walletRef, { 
        balance: newBalance,
        totalEarnings: type === 'credit' ? (walletDoc.data().totalEarnings || 0) + amount : walletDoc.data().totalEarnings
      });

      const txData = {
        amount,
        type,
        status: 'completed',
        description,
        timestamp: serverTimestamp(),
      };
      
      // We can't use addDoc inside a transaction easily without a ref, 
      // but we can create a doc ref first.
      const newTxRef = doc(transactionsRef);
      transaction.set(newTxRef, txData);
    });
  } catch (err: any) {
    const permissionError = new FirestorePermissionError({
      path: `wallets/${uid}`,
      operation: 'write',
      requestResourceData: { amount, type, description },
    });
    errorEmitter.emit('permission-error', permissionError);
    throw err;
  }
}
